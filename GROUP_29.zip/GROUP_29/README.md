README

Our Music Ontology contains the information of today's most current music trends. It is in the form of a TTL file and is meant to be open the Protege ontology app.

In the event that the Protege asks for missing import file, include the Music_Ontology_Outside_Source to ensure that there are no problems.

When opening the ttl file in Protege, on the bottom, check that there isn't an extra empty prefix. Often times when opening up a new ontology, Protege will have a tendency to
create a new prefix based on the current Ontology IRI. Delete this by clicking on the prefix and clicking the rightmost button to delete the prefix.

Continuing, click on File - Preferences and click on New Entities. Ensure that Start With: is at Active Ontology IRI and Followed by: is at the hash and not the slash. This will allow
for Protege to read the Music Ontology based on the predefined prefix with a hash. After that, click on Renderer. Make sure Entity Rendering is as Render by Prefixed Name. This will allow
renderer to just load the name of the instance, class, object properties, and data. Not doing so will include the IRI link.

You will now have the functioning Music Ontology.

Classes will contain related information regarding the entire ontology such as any class restrcitions such as equivalences and subclasses, disjoint relations, along with instances of the
entire protege.

Object and data properties contains relational properties between two classes or instances. Examples of these properties are: md:hasAlbum and ms:composes.

Instances are individual objects in an ontology. In our Music Ontology, these contains objects such as artists, genres, albums, and much more.

The reasoner infers and maps various types of information throughout the ontology. Run the reasoner by clicking Reasoner -> Start Reasoner; or click on Ctrl+R.

The Jupyter Notebook included in the ZIP-file is meant to run the visualizer. In order to run the visualizer, the user needs to download and run GraphDB. Create a repository by clicking on
Setup -> Repositories -> Create new repository. Click on GraphDB Free and call it musicgenres. Afterwards, Click on import -> Upload RDF files, and upload the ontology file. Once this is
done, run the Jupyter Notebook from the zip-file and run click on the Restart the Kernal, then re-run the whole kernel button. This is in the shape of two play buttons next to each other.
